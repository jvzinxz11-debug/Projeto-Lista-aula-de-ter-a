
tarefas = []



def adicionar_tarefa():
    """Cadastra uma nova tarefa no sistema."""
    titulo = input("Digite o título da tarefa: ")
    descricao = input("Digite a descrição da tarefa: ")
    prioridade = input("Prioridade (baixa / média / alta): ")

    tarefa = {
        "titulo": titulo,
        "descricao": descricao,
        "prioridade": prioridade
    }

    tarefas.append(tarefa)
    print("\n✔ Tarefa adicionada com sucesso!\n")


def listar_tarefas():
    """Lista todas as tarefas cadastradas."""
    if not tarefas:
        print("\n✖ Nenhuma tarefa cadastrada.\n")
        return

    print("\n====== LISTA DE TAREFAS ======")
    for i, tarefa in enumerate(tarefas):
        print(f"\nID: {i}")
        print(f"Título: {tarefa['titulo']}")
        print(f"Descrição: {tarefa['descricao']}")
        print(f"Prioridade: {tarefa['prioridade']}")
    print("===============================\n")


def atualizar_tarefa():
    """Atualiza uma tarefa existente."""
    listar_tarefas()

    if not tarefas:
        return

    try:
        id_tarefa = int(input("Digite o ID da tarefa que deseja atualizar: "))

        if id_tarefa < 0 or id_tarefa >= len(tarefas):
            print("ID inválido!")
            return

        print("\nDeixe em branco caso não queira alterar um campo.\n")

        novo_titulo = input("Novo título: ")
        nova_desc = input("Nova descrição: ")
        nova_prioridade = input("Nova prioridade: ")

        if novo_titulo:
            tarefas[id_tarefa]["titulo"] = novo_titulo
        if nova_desc:
            tarefas[id_tarefa]["descricao"] = nova_desc
        if nova_prioridade:
            tarefas[id_tarefa]["prioridade"] = nova_prioridade

        print("\n✔ Tarefa atualizada com sucesso!\n")

    except ValueError:
        print("Entrada inválida! Digite um número.")


def excluir_tarefa():
    """Exclui uma tarefa pelo ID."""
    listar_tarefas()

    if not tarefas:
        return

    try:
        id_tarefa = int(input("Digite o ID da tarefa a excluir: "))

        if id_tarefa < 0 or id_tarefa >= len(tarefas):
            print("ID inválido!")
            return

        tarefas.pop(id_tarefa)
        print("\n✔ Tarefa removida com sucesso!\n")

    except ValueError:
        print("Entrada inválida!")


# =========================================================
# MENU PRINCIPAL
# =========================================================

def exibir_menu():
    """Mostra o menu principal do sistema."""
    print("====== GERENCIADOR DE TAREFAS ======")
    print("1 - Adicionar tarefa")
    print("2 - Listar tarefas")
    print("3 - Atualizar tarefa")
    print("4 - Excluir tarefa")
    print("5 - Sair")
    print("====================================")


def main():
    """Executa o programa principal."""
    while True:
        exibir_menu()
        opcao = input("Escolha uma opção: ")

        if opcao == "1":
            adicionar_tarefa()
        elif opcao == "2":
            listar_tarefas()
        elif opcao == "3":
            atualizar_tarefa()
        elif opcao == "4":
            excluir_tarefa()
        elif opcao == "5":
            print("Saindo... Até mais!")
            break
        else:
            print("Opção inválida! Tente novamente.\n")


# Executa o programa
main()